package com.example.tpi;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class AddTransactionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_transaction);

        EditText amountEditText = findViewById(R.id.edit_amount);
        EditText categoryEditText = findViewById(R.id.edit_category);
        DatePicker datePicker = findViewById(R.id.datePicker);
        RadioGroup typeRadioGroup = findViewById(R.id.radio_group_type);
        Button addButton = findViewById(R.id.button_add_transaction);

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int selectedId = typeRadioGroup.getCheckedRadioButtonId();
                RadioButton selectedRadioButton = findViewById(selectedId);
                String type = selectedRadioButton.getText().toString();

                String amount = amountEditText.getText().toString();
                String category = categoryEditText.getText().toString();
                int day = datePicker.getDayOfMonth();
                int month = datePicker.getMonth() + 1;
                int year = datePicker.getYear();
                String date = day + "/" + month + "/" + year;

                if (!amount.isEmpty() && !category.isEmpty()) {
                    int userId = 1;
                    new ServerCommunicator(AddTransactionActivity.this).execute("ADD_TRANSACTION|" + userId + "|" + amount + "|" + type + "|" + category + "|" + date);
                } else {
                    Toast.makeText(AddTransactionActivity.this, "Te rugăm să completezi toate câmpurile.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}