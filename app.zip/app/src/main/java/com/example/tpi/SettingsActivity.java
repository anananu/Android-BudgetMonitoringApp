package com.example.tpi;

public class SettingsActivity {
}
