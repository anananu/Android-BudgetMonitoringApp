package com.example.tpi;

import android.os.AsyncTask;
import android.widget.Toast;

import com.example.tpi.LoginScreen;
import com.example.tpi.RegisterScreen1;

import java.io.*;
import java.net.*;

public class ServerCommunicator extends AsyncTask<String, Void, String> {
    private Object context;
    public ServerCommunicator(Object context) {
        this.context = context;
    }
    @Override
    protected String doInBackground(String... params) {
        String serverAddress = "192.168.0.199";
        int serverPort = 8080;
        try {
            Socket socket = new Socket(serverAddress, serverPort);
            OutputStream outputStream = socket.getOutputStream();
            PrintWriter out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(outputStream)));
            String message = "";
            if (context instanceof LoginScreen) {
                message = "LOGIN|" + params[0] + "|" + params[1];
            } else if (context instanceof RegisterScreen1) {
                message = "CREATE_ACCOUNT|" + params[0] + "|" + params[1] + "|" + params[2];
            }
            out.println(message);
            out.flush();
            InputStream inputStream = socket.getInputStream();
            BufferedReader in = new BufferedReader(new InputStreamReader(inputStream));
            String response = in.readLine();
            socket.close();
            return response;
        } catch (IOException e) {
            e.printStackTrace();
            return "Eroare la conectare cu serverul";
        }
    }
    @Override
    protected void onPostExecute(String result) {
        if (result != null) {
            if (context instanceof LoginScreen) {
                Toast.makeText((LoginScreen) context, result, Toast.LENGTH_SHORT).show();
            } else if (context instanceof RegisterScreen1) {
                Toast.makeText((RegisterScreen1) context, result, Toast.LENGTH_SHORT).show();
            }
        } else {
            if (context instanceof LoginScreen) {
                Toast.makeText((LoginScreen) context, "Eroare la conectare cu serverul", Toast.LENGTH_SHORT).show();
            } else if (context instanceof RegisterScreen1) {
                Toast.makeText((RegisterScreen1) context, "Eroare la conectare cu serverul", Toast.LENGTH_SHORT).show();
            }
        }
    }
}