package com.example.tpi;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LoginScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        EditText emailField = findViewById(R.id.email);
        EditText passwordField = findViewById(R.id.password);
        Button loginButton = findViewById(R.id.login_button);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = emailField.getText().toString();
                String password = passwordField.getText().toString();
                if (!email.isEmpty() && !password.isEmpty()) {
                    ServerCommunicator communicator = new ServerCommunicator(LoginScreen.this) {
                        @Override
                        protected void onPostExecute(String result) {
                            if (result != null && result.equals("Autentificare reușită!")) {
                                Intent intent = new Intent(LoginScreen.this, MainMenuActivity.class);
                                startActivity(intent);
                                finish();
                            } else {
                                Toast.makeText(LoginScreen.this, result, Toast.LENGTH_SHORT).show();
                            }
                        }
                    };
                    communicator.execute(email, password);
                } else {
                    Toast.makeText(LoginScreen.this, "Invalid email or password. Try again.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}