package server;

import java.io.*;
import java.net.*;
import java.sql.*;

public class server {
    
    public static void adaugaUtilizator(String username, String parola, String email) {
        String url = "jdbc:mysql://localhost:3306/wallet?useSSL=false"; 
        String username1 = "root"; 
        String password1 = "elenadaniela16"; 
        try {
            
            Connection connection = DriverManager.getConnection(url, username1, password1);

            PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO utilizatori (Username, Parola, Email) VALUES (?, ?, ?)");
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, parola);
            preparedStatement.setString(3, email);
            preparedStatement.executeUpdate();

            System.out.println("Utilizatorul a fost adăugat cu succes în baza de date!");

            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static boolean autentificareUtilizator(String email, String parola) {

        String url = "jdbc:mysql://localhost:3306/wallet?useSSL=false"; 
        String username1 = "root";
        String password1 = "elenadaniela16";

        try {
            
            Connection connection = DriverManager.getConnection(url, username1, password1);

            PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM utilizatori WHERE Email=? AND Parola=?");
            preparedStatement.setString(1, email);
            preparedStatement.setString(2, parola);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {  
                connection.close();
                return true;
            }

            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }
    public static void main(String[] args) {
        try {
            ServerSocket serverSocket = new ServerSocket(8080);
            System.out.println("Serverul asculta pe portul 8080...");
            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Clientul s-a conectat: " + clientSocket);
                BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
                String message = in.readLine();
                System.out.println("Mesaj primit de la client: " + message);

                String[] data = message.split("\\|");
                if (data.length == 4 && data[0].equals("CREATE_ACCOUNT")) {
                    String email = data[1];
                    String username = data[2];
                    String password = data[3];

                    adaugaUtilizator(username, password, email);

                    out.println("Cont creat cu succes!");
                } else if (data.length == 3 && data[0].equals("LOGIN")) {
                    String email = data[1];
                    String password = data[2];

                    if (autentificareUtilizator(email, password)) {
                        out.println("Autentificare reușită!");
                    } else {
                        out.println("Eroare: Email sau parolă incorecte!");
                    }
                } else {
                    out.println("Eroare: Cerere invalidă!");
                }
                clientSocket.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}